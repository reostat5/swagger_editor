require("core-js/fn/object/values")
require("core-js/fn/object/assign")
require("core-js/es6/string")
require("core-js/es6/array")
